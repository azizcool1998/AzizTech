<?php

namespace Pterodactyl\Exceptions\Service\Egg\Variable;

use Pterodactyl\Exceptions\DisplayException;

class BadValidationRuleException extends DisplayException
{
}
