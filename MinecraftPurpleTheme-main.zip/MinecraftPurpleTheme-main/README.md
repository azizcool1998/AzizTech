# MinecraftPurpleTheme

Install script:
```sh
bash <(curl https://raw.githubusercontent.com/Angelillo15/MinecraftPurpleTheme/main/install.sh)
```

Screenshots:
![Main panel screenshot](https://cdn.discordapp.com/attachments/920581510510297169/1001607296138362880/Captura_de_pantalla_2022-07-26_212549.png "Main panel screenshot")
![Main panel screenshot](https://media.discordapp.net/attachments/920581510510297169/1001607296746528778/Captura_de_pantalla_2022-07-26_215606.png "Main panel screenshot")
# Instalation Script
![Instalation script](https://i.imgur.com/8hFZG5b.png "Instalation script")
